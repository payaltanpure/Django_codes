from django.shortcuts import render
from .models import student

# Create your views here.

def add(request):
   if request.method == "POST":
      name= request.POST.get("name")
      marks= request.POST.get("marks")

      student.objects.create(
         name= name,
         marks= marks
      )
      

   return render(request, "crud_operation/index.html")



